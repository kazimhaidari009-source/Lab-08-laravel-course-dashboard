<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CourseController extends Controller
{
    public function index(Request $request)
    {
        return $this->dashboard($request);
    }

    public function store(Request $request)
    {
        $data = $this->validatedData($request);
        $data['user_id'] = $request->user()->id;

        Course::create($data);

        return redirect()
            ->route('dashboard')
            ->with('success', 'Course registered successfully.');
    }

    public function show(Request $request, int $course)
    {
        $record = $this->ownedCourse($request, $course);

        return $this->dashboard($request, null, $record);
    }

    public function edit(Request $request, int $course)
    {
        $record = $this->ownedCourse($request, $course);

        return $this->dashboard($request, $record);
    }

    public function update(Request $request, int $course)
    {
        $record = $this->ownedCourse($request, $course);
        $data = $this->validatedData($request, $record);

        $record->update($data);

        return redirect()
            ->route('dashboard')
            ->with('success', 'Course updated successfully.');
    }

    public function destroy(Request $request, int $course)
    {
        $record = $this->ownedCourse($request, $course);
        $record->delete();

        return redirect()
            ->route('dashboard')
            ->with('success', 'Course deleted successfully.');
    }

    private function dashboard(
        Request $request,
        ?Course $editing = null,
        ?Course $viewing = null
    ) {
        $courses = Course::where('user_id', $request->user()->id)
            ->latest()
            ->get();

        return view('dashboard', [
            'courses' => $courses,
            'editingCourse' => $editing,
            'viewingCourse' => $viewing,
        ]);
    }

    /**
     * Find a course only if it belongs to the currently signed-in user.
     * Returning 404 avoids exposing another user's course.
     */
    private function ownedCourse(Request $request, int $course): Course
    {
        return Course::where('user_id', $request->user()->id)
            ->findOrFail($course);
    }

    private function validatedData(
        Request $request,
        ?Course $course = null
    ): array {
        $request->merge([
            'course_code' => strtoupper(trim((string) $request->input('course_code'))),
        ]);

        $uniqueCode = Rule::unique('courses', 'course_code')
            ->where(fn ($query) => $query->where('user_id', $request->user()->id));

        if ($course) {
            $uniqueCode->ignore($course->id);
        }

        return $request->validate([
            'course_code' => ['required', 'string', 'max:20', $uniqueCode],
            'course_name' => ['required', 'string', 'max:150'],
            'credit_hours' => ['required', 'integer', 'between:1,6'],
            'semester' => ['required', Rule::in(['Spring 2026', 'Fall 2026'])],
        ]);
    }
}
