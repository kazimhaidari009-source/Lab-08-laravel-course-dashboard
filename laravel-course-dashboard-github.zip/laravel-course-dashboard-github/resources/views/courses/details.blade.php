<section class="panel details-panel">
    <div class="panel-heading details-heading">
        <div>
            <p class="eyebrow">COURSE INFORMATION</p>
            <h2>{{ $course->course_name }}</h2>
            <p>Read-only details for this course.</p>
        </div>
        <a class="button button-secondary" href="{{ route('dashboard') }}">Close</a>
    </div>

    <div class="details-grid">
        <div class="detail-item">
            <span>Course code</span>
            <strong>{{ $course->course_code }}</strong>
        </div>
        <div class="detail-item">
            <span>Course name</span>
            <strong>{{ $course->course_name }}</strong>
        </div>
        <div class="detail-item">
            <span>Credit hours</span>
            <strong>{{ $course->credit_hours }}</strong>
        </div>
        <div class="detail-item">
            <span>Semester</span>
            <strong>{{ $course->semester }}</strong>
        </div>
        <div class="detail-item">
            <span>Registered on</span>
            <strong>{{ $course->created_at?->format('M d, Y') ?? '—' }}</strong>
        </div>
    </div>

    <div class="form-actions">
        <a class="button button-primary" href="{{ route('courses.edit', $course->id) }}">Edit course</a>
    </div>
</section>
