@php
    $isEditing = isset($editingCourse) && $editingCourse;
    $formCourse = $isEditing ? $editingCourse : null;
@endphp

<div class="panel-heading">
    <p class="eyebrow">{{ $isEditing ? 'UPDATE RECORD' : 'NEW RECORD' }}</p>
    <h2>{{ $isEditing ? 'Edit course' : 'Register a course' }}</h2>
    <p>{{ $isEditing ? 'Update the course information below.' : 'Enter the details of the course you are taking.' }}</p>
</div>

@if ($errors->any())
    <div class="notice notice-error">
        <strong>Please correct the following:</strong>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form
    method="POST"
    action="{{ $isEditing ? route('courses.update', $formCourse->id) : route('courses.store') }}"
    class="course-form"
>
    @csrf
    @if ($isEditing)
        @method('PUT')
    @endif

    <div class="form-field">
        <label for="course_code">Course code</label>
        <input
            id="course_code"
            name="course_code"
            type="text"
            maxlength="20"
            value="{{ old('course_code', $formCourse->course_code ?? '') }}"
            placeholder="e.g. CS101"
            required
        >
        @error('course_code') <small class="field-error">{{ $message }}</small> @enderror
    </div>

    <div class="form-field">
        <label for="course_name">Course name</label>
        <input
            id="course_name"
            name="course_name"
            type="text"
            maxlength="150"
            value="{{ old('course_name', $formCourse->course_name ?? '') }}"
            placeholder="e.g. Introduction to Programming"
            required
        >
        @error('course_name') <small class="field-error">{{ $message }}</small> @enderror
    </div>

    <div class="form-field">
        <label for="credit_hours">Credit hours</label>
        <input
            id="credit_hours"
            name="credit_hours"
            type="number"
            min="1"
            max="6"
            value="{{ old('credit_hours', $formCourse->credit_hours ?? '') }}"
            required
        >
        @error('credit_hours') <small class="field-error">{{ $message }}</small> @enderror
    </div>

    <div class="form-field">
        <label for="semester">Semester</label>
        <select id="semester" name="semester" required>
            <option value="">Choose a semester</option>
            <option value="Spring 2026" @selected(old('semester', $formCourse->semester ?? '') === 'Spring 2026')>Spring 2026</option>
            <option value="Fall 2026" @selected(old('semester', $formCourse->semester ?? '') === 'Fall 2026')>Fall 2026</option>
        </select>
        @error('semester') <small class="field-error">{{ $message }}</small> @enderror
    </div>

    <div class="form-actions">
        <button class="button button-primary" type="submit">
            {{ $isEditing ? 'Save changes' : 'Register course' }}
        </button>

        @if ($isEditing)
            <a class="button button-secondary" href="{{ route('dashboard') }}">Cancel</a>
        @endif
    </div>
</form>
