<div class="panel-heading table-heading">
    <div>
        <p class="eyebrow">YOUR RECORDS</p>
        <h2>Registered courses</h2>
        <p>Courses registered under your account.</p>
    </div>
    <span class="count-pill">{{ $courses->count() }} total</span>
</div>

@if ($courses->isEmpty())
    <div class="empty-state">
        <div class="empty-icon">＋</div>
        <h3>No courses yet</h3>
        <p>Use the form to register your first course.</p>
    </div>
@else
    <div class="table-wrap">
        <table class="course-table">
            <thead>
                <tr>
                    <th>Course</th>
                    <th>Credit hours</th>
                    <th>Semester</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($courses as $course)
                    <tr>
                        <td data-label="Course">
                            <strong>{{ $course->course_code }}</strong>
                            <span class="course-subtitle">{{ $course->course_name }}</span>
                        </td>
                        <td data-label="Credit hours">{{ $course->credit_hours }}</td>
                        <td data-label="Semester">{{ $course->semester }}</td>
                        <td data-label="Actions">
                            <div class="action-list">
                                <a class="text-link" href="{{ route('courses.show', $course->id) }}">View</a>
                                <a class="text-link" href="{{ route('courses.edit', $course->id) }}">Edit</a>
                                <form
                                    method="POST"
                                    action="{{ route('courses.destroy', $course->id) }}"
                                    onsubmit="return confirm('Are you sure you want to delete this course?');"
                                >
                                    @csrf
                                    @method('DELETE')
                                    <button class="text-link text-danger" type="submit">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endif
