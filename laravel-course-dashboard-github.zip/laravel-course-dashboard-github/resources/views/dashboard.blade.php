<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Dashboard</title>
    <link rel="stylesheet" href="{{ asset('css/dashboard.css') }}">
</head>
<body>
    <header class="topbar">
        <div class="topbar-inner">
            <a class="brand" href="{{ route('dashboard') }}">Course Portal</a>

            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="button button-light" type="submit">Log out</button>
            </form>
        </div>
    </header>

    <main class="page-container">
        <section class="welcome">
            <p class="eyebrow">STUDENT WORKSPACE</p>
            <h1>Welcome, {{ auth()->user()->name }}</h1>
            <p>Register and manage your courses in one place.</p>
        </section>

        @if (session('success'))
            <div class="notice notice-success">{{ session('success') }}</div>
        @endif

        <div class="dashboard-grid">
            <section class="panel">
                @include('courses.form')
            </section>

            <section class="panel">
                @include('courses.table')
            </section>
        </div>

        @if ($viewingCourse)
            @include('courses.details', ['course' => $viewingCourse])
        @endif
    </main>
</body>
</html>
