# Laravel Course Dashboard — View, Edit and Delete

A GitHub-ready **feature package** for extending an existing Laravel 12 authentication/course-registration project.

> This repository contains the assignment files to copy into an existing Laravel application. It is not a complete Laravel installation and does not include your existing authentication system, `.env`, database, or `vendor/` directory.

## Features

- Authenticated dashboard
- Create and list the signed-in user's courses
- View course details
- Edit an existing course
- Delete a course after browser confirmation
- Validation and per-user course-code uniqueness
- Ownership protection: users cannot view, edit, or delete another user's courses
- Responsive CSS

## Requirements

- PHP version supported by your Laravel 12 installation
- Laravel 12
- Composer
- MySQL / MariaDB (or another configured Laravel database)
- Existing working Laravel authentication routes and users table

## Installation

1. Open your existing Laravel project.
2. Copy the files from this repository into the matching locations shown below. Do not replace your whole project.
3. Confirm that the `courses` table contains these columns:
   - `id`
   - `user_id`
   - `course_code`
   - `course_name`
   - `credit_hours`
   - `semester`
   - timestamps
4. Confirm that `user_id` references `users.id` and that your model/table names match.
5. Keep your existing authentication routes. Add the course routes from `routes/web.php` only if equivalent routes do not already exist.
6. Run:

   ```bash
   php artisan optimize:clear
   php artisan route:list --path=dashboard
   php artisan route:list --path=courses
   php artisan serve
   ```

7. Sign in and open `http://127.0.0.1:8000/dashboard`.

## File map

Copy each file to the corresponding path in your Laravel application:

```text
app/
└── Models/
    └── Course.php
app/
└── Http/
    └── Controllers/
        └── CourseController.php
routes/
└── web.php
resources/
└── views/
    ├── dashboard.blade.php
    └── courses/
        ├── form.blade.php
        ├── table.blade.php
        └── details.blade.php
public/
└── css/
    └── dashboard.css
```

## Important route note

The `routes/web.php` in this repository is a **snippet** intended to merge into your existing route file. If your project already has a dashboard route, do not create a duplicate route with the same name. Keep your existing login, registration, and logout routes.

## Test checklist

- [ ] Sign in and open `/dashboard`.
- [ ] Register a course with valid details.
- [ ] Confirm the course appears in the table.
- [ ] Open **View** and verify the read-only details.
- [ ] Open **Edit**, change a field, and save.
- [ ] Edit a course without changing its course code.
- [ ] Try registering the same course code twice for the same user, even in a different semester.
- [ ] Cancel a deletion, then test deletion and confirm the row disappears.
- [ ] Create a second user and verify that the second user cannot access the first user's course by changing the URL ID.
- [ ] Check the layout at desktop and mobile widths.

## Safety

Do **not** run `php artisan migrate:fresh` on a database containing data you need. It drops existing tables. Use your normal migration workflow and back up important data first.

## Troubleshooting

- **View not found:** check the Blade file names and folders under `resources/views`.
- **Route not defined:** run `php artisan route:list` and check route names.
- **Undefined `$courses`:** confirm the dashboard controller passes the `$courses` variable.
- **405 Method Not Allowed:** check the form's `@method('PUT')` or `@method('DELETE')`.
- **419 Page Expired:** ensure forms include `@csrf`.
- **CSS not loading:** confirm the file is at `public/css/dashboard.css` and the view uses `asset('css/dashboard.css')`.

## Before submission

Update this README with your name, course/module, lecturer, and screenshots if your instructor requires them. Do not commit `.env`, passwords, API keys, or database credentials.
