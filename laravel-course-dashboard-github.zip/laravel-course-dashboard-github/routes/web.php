<?php

use App\Http\Controllers\CourseController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Course dashboard routes
|--------------------------------------------------------------------------
| Merge these routes into your existing routes/web.php.
| Keep your existing login, registration, and logout routes.
| Do not add a duplicate dashboard route if your project already has one.
*/

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [CourseController::class, 'index'])
        ->name('dashboard');

    Route::post('/courses', [CourseController::class, 'store'])
        ->name('courses.store');

    Route::get('/courses/{course}/edit', [CourseController::class, 'edit'])
        ->whereNumber('course')
        ->name('courses.edit');

    Route::get('/courses/{course}', [CourseController::class, 'show'])
        ->whereNumber('course')
        ->name('courses.show');

    Route::put('/courses/{course}', [CourseController::class, 'update'])
        ->whereNumber('course')
        ->name('courses.update');

    Route::delete('/courses/{course}', [CourseController::class, 'destroy'])
        ->whereNumber('course')
        ->name('courses.destroy');
});
